Clazz.declarePackage ("JS");
Clazz.load (["JS.LayoutManager"], "JS.GridBagLayout", null, function () {
c$ = Clazz.declareType (JS, "GridBagLayout", JS.LayoutManager);
});
